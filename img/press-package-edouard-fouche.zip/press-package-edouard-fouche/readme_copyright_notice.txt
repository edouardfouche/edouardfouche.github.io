readme_copyright_notice
-----------------------
The usage of pictures in this folder is only permitted for the personal and professional promotion of Edouard Fouché.
Modifications beyond cropping and light brightness/contrast/color adjustments are not permitted. 
Please attribute the copyright to the photograph: @cheriebirkner / Cherie Birkner

Sincerely yours,
Edouard Fouché